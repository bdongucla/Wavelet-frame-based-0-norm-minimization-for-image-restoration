% aim to solve the image restoration problem for CT application:
% min  |Pu - f|^2/2 + sum_i (lambda*wlevel_i*|d_i|_0) 
% s.t. 0 <= u, Wu = d,
% by applying the PD method to the problem:
% min  |Pu - f|^2/2 + sum_i (lambda*wlevel_i*|d_i|_0)
% s.t. Wu - d = 0, 
%      0 <= u.
%
%------ input ------
%
% f      - the d x 1 observation vector.
% P      - the d x n partial Radon transformation matrix.
% mu     - Initial penalty parameter for PD method.
% lambda - sparsity penlaty parameter.
% wLevel - weighting of sparsity penalty parameter lambda on each level. 
%          The thresholding is multiplied by wLevel from the current 
%          level to the next level. 
% tol    - the tolerance for termination.
% maxit  - the maximum of number of iterations for running code
%
%------ output ------
%
% u      - Restored image

function u = WaveletPD_CT(f,P,mu,lambda,wLevel,tol,maxit)

%initialization
frame = 1; Level = 4;
[D,R] = GenerateFrameletFilter(frame);
W  = @(x) FraDecMultiLevel(x,D,Level); % Frame decomposition
WT = @(x) FraRecMultiLevel(x,R,Level); % Frame reconstruction
A = @(x) P*x;
AT = @(x) P'*x;
m = sqrt(size(P,2));
n = m;  
u = zeros(m,n);
d = W(u);
Tol =1e-3;
iter = 1;

fprintf('Processing.')

while (iter < maxit)
    muLevel = getwThresh(2*lambda/mu,wLevel,Level,D);
    obj_old = 0.5*norm(A(u(:))-f(:),'fro')^2 + cellnorm(d,0,muLevel)*mu/2+cellnorm(CoeffOper('-',W(u),d),2)^2*mu/2;
    while (iter < maxit)
        % Solve u
        tmp = mu*WT(d);
        u = Lower_QP_spg(A,AT,tmp(:)+AT(f(:)),mu,0,u(:),5e-5);
        u = reshape(u,m,n);
        % Solve d
        C=FraDecMultiLevel(u,D,Level);
        d=CoeffOper('l0',C,muLevel);
        OBJ = 0.5*norm(A(u(:))-f(:),'fro')^2 + cellnorm(d,0,muLevel)*mu/2;
        res = cellnorm(CoeffOper('-',W(u),d),2);
        obj = OBJ + res^2*mu/2;
        error = abs(obj_old-obj)/max(obj,1);
        obj_old = obj;
        if mod(iter,5) == 0
            fprintf('.');
        end
        iter = iter+1;
        if (error<Tol || (error <=5*tol && res/max(obj,1) < 1e-3)) 
            break;        
        end
    end
    if res/max(obj,1) < 1e-3
        break; 
    end;
    mu = min(10*mu,1e15);
    Tol = max(Tol/10, tol);
end

fprintf('\nDone\n')

