P = pwd;
n = strfind(P,'Examples');
P = P(1:n-2);
addpath(P);
addpath(strcat(P,'/Utilities'));
clear P n

% Generate test data
rand('seed',3000);
randn('seed',3000);
load lena
ker=fspecial('gaussian',9,1.5);
sigma=3;
blur=@(f,k)imfilter(f,k,'circular');
og=blur(img,ker);
g=og+sigma*randn(size(img));
cker = rot90(ker);
P = @(x) blur(x,ker); PT = @(x) blur(x,cker);


%% Testing the PD method
tol = 1e-4;
mu = 0.001;     
wLevel = 0.8;
lambda = 0.2; 
maxit=500;
t = clock;
u = WaveletPD_deblur(g,P,PT,mu,lambda,wLevel,tol,maxit);
t = etime(clock,t);
pval = psnr(u/255,img/255);


%% Show results
fprintf('\nResults of the PD method: \n')
fprintf('Processing time is %3.2f \n', t);
fprintf('PSNR is %3.2f \n \n',pval); 
figure;
ax(1)=subplot(131);imshow(g,[]);title('Blurred image');
ax(2)=subplot(132);imshow(img,[]);title('Original image');
ax(3)=subplot(133);imshow(u,[]);title('Recovered image');
linkaxes(ax);
