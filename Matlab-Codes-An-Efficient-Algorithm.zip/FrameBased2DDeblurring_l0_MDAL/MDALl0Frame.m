function [u, T]=MDALl0Frame(f,ker,blur,mu,lambda,gamma,tol,frame,Level,maxit,oimg)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%   lambda*||Wu||_0+1/2||Au-f||_2^2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

t1=clock;

[D,R]=GenerateFrameletFilter(frame);nD=length(D);
W  = @(x) FraDecMultiLevel(x,D,Level); % Frame decomposition
WT = @(x) FraRecMultiLevel(x,R,Level); % Frame reconstruction
[m,n]=size(f);
cker=rot90(ker,2);

A = @(x) blur(x,ker); AT = @(x) blur(x,cker); % Convolution operator

eigenP=eigenofP(ker,mu+gamma,m,n);

FT = @(x)fft2(x);
IFT = @(x)ifft2(x);

normg=norm(f,'fro');normW=cellnorm(W(f));

%initialization
u=zeros(m,n);
b=W(f);
d=b;
umean=0;dmean=W(u);bmean=dmean;
T = zeros(1,maxit); T2 = 0;
ATf=AT(f);

for nstep=1:maxit
    
    % solve u.
    
    C=CoeffOper('-',d,b);
    u=IFT(FT(mu*WT(C)+ATf+gamma*u)./eigenP);
    u(u>255)=255;u(u<0)=0;
    C=W(u);
%     vtemp=C{1}{1,2};vtemp=double(abs(vtemp(:))>0);figure(1);stem(vtemp(700:900));ylim([0 1.1]);title(num2str(nstep));drawnow;
    
    % solve d
    Cpb=CoeffOper('+',C,b);
%     d=CoeffOper('l0',Cpb,muLevel);
    d=DALHT(Cpb,d,lambda,mu,gamma);
    
    % update b
    deltab=CoeffOper('-',C,d);
    b=CoeffOper('+',b,deltab);
    
    dmean=CoeffOper('+',d,dmean);
    bmean=CoeffOper('+',b,bmean);
    umeant=umean;umean=umean+u;
    error=norm(umean/nstep-umeant/(nstep-1),'fro')/normg;
    t2 = clock;
    uu = umean/nstep;
    meanresidual1=cellnorm(CoeffOper('-',W(uu),CoeffOper('*',dmean,1/nstep)))/normW;
    meanresidual2=cellnorm(CoeffOper('-',CoeffOper('*',dmean,1/nstep),DALHT(CoeffOper('+',CoeffOper('*',dmean,1/nstep),CoeffOper('*',bmean,1/nstep)),CoeffOper('*',dmean,1/nstep),lambda,mu,gamma)))/normW;
%     E1(nstep)=meanresidual1;E2(nstep)=meanresidual2;
    disp(['error on step ' num2str(nstep) ' is ' num2str(error) ', ' num2str(meanresidual1) ', and PSNR is ' num2str(psnr(uu/255,oimg/255))]);
    t2 = etime(clock,t2);
    T2 = T2 + t2;
    T(nstep) = etime(clock,t1) - T2; 
    
    if error<tol
        break;
    end
end
u=umean/nstep;
T = T(1:nstep);
u(u>255)=255;u(u<0)=0;

function eigenP=eigenofP(ker,mu,m,n)

[nker,mker]=size(ker);
tmp=zeros(m,n);tmp(1:nker,1:mker)=ker;
tmp=circshift(tmp,[-floor(nker/2),-floor(mker/2)]);
eigenP=abs(fft2(tmp)).^2+mu;

function [D,R]=GenerateFrameletFilter(frame)
if frame==0          %Haar Wavelet
    D{1}=[0 1 1]/2;
    D{2}=[0 1 -1]/2;
    D{3}='cc';
    R{1}=[1 1 0]/2;
    R{2}=[-1 1 0]/2;
    R{3}='cc';
elseif frame==1      %Piecewise Linear Framelet
    D{1}=[1 2 1]/4;
    D{2}=[1 0 -1]/4*sqrt(2);
    D{3}=[-1 2 -1]/4;
    D{4}='ccc';
    R{1}=[1 2 1]/4;
    R{2}=[-1 0 1]/4*sqrt(2);
    R{3}=[-1 2 -1]/4;
    R{4}='ccc';
elseif frame==3      %Piecewise Cubic Framelet
    D{1}=[1 4 6 4 1]/16;
    D{2}=[1 2 0 -2 -1]/8;
    D{3}=[-1 0 2 0 -1]/16*sqrt(6);
    D{4}=[-1 2 0 -2 1]/8;
    D{5}=[1 -4 6 -4 1]/16;
    D{6}='ccccc';
    R{1}=[1 4 6 4 1]/16;
    R{2}=[-1 -2 0 2 1]/8;
    R{3}=[-1 0 2 0 -1]/16*sqrt(6);
    R{4}=[1 -2 0 2 -1]/8;
    R{5}=[1 -4 6 -4 1]/16;
    R{6}='ccccc';
end

function muLevel=getwThresh(mu,wLevel,Level,D)
nfilter=1;
nD=length(D);
if wLevel<=0
    for ki=1:Level
        for ji=1:nD-1
            for jj=1:nD-1
                muLevel{ki}{ji,jj}=mu*nfilter*norm(D{ji})*norm(D{jj});
            end
        end
        nfilter=nfilter*norm(D{1});
    end
else
    for ki=1:Level
        for ji=1:nD-1
            for jj=1:nD-1
                if ji==1 && jj==1
                    muLevel{ki}{ji,jj}=0;
                else
                    muLevel{ki}{ji,jj}=mu*nfilter;
                end
            end
        end
        %         muLevel{ki}{1,2}=0;muLevel{ki}{2,1}=0;
        %         muLevel{ki}{2,2}=0;
        %muLevel{ki}{2,3}=0;muLevel{ki}{3,2}=0;
        %muLevel{ki}{3,3}=0;
        nfilter=nfilter*wLevel;
    end
end