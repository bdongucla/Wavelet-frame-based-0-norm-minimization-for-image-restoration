clear
clc

img=double(imread('lena.png'));ker=fspecial('gaussian',9,1.5);

sigma=3;
blur=@(f,k)imfilter(f,k,'circular');
og=blur(img,ker); % adding blur
g=og+sigma*randn(size(img)); % adding noise

Level=4;
frame=1;
tol=5e-4;
maxit=500;

lambda=1.0;
mu=0.01;
gamma=0.003;

[u T]=MDALl0Frame(g,ker,blur,mu,lambda,gamma,tol,frame,Level,maxit,img);

PSNR=psnr(u/255,img/255);
ax(1)=subplot(121);imshow(g,[]);ax(2)=subplot(122);imshow(u,[]);title(['PSNR = ' num2str(PSNR) ', Time = ' num2str(T(end))]);linkaxes(ax);