function c=DALHT(alpha,beta,lambda,mu,gamma)
Level=length(alpha);lambda0=lambda;
[nD,nD1]=size(alpha{1});c=alpha;
for ki=1:Level
    for ji=1:nD
        for jj=1:nD
            if (ji~=1 || jj~=1)
                lambda=lambda0*(0.25)^(ki-1);
%                 T=lambda+(mu*gamma)/2/(gamma+mu)*(alpha{ki}{ji,jj}-beta{ki}{ji,jj}).^2-(mu/2*alpha{ki}{ji,jj}.^2+gamma/2*beta{ki}{ji,jj}.^2);
%                 c{ki}{ji,jj}=double(T<0).*(mu/(mu+gamma)*alpha{ki}{ji,jj}+gamma/(mu+gamma)*beta{ki}{ji,jj});
                c{ki}{ji,jj}=double((mu*alpha{ki}{ji,jj}+gamma*beta{ki}{ji,jj}).^2-2*lambda*(mu+gamma)>0).*(mu/(mu+gamma)*alpha{ki}{ji,jj}+gamma/(mu+gamma)*beta{ki}{ji,jj});
            else
                c{ki}{ji,jj}=alpha{ki}{ji,jj};
            end
        end
    end
end